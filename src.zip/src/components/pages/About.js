import React from 'react'

function About() {
    return (
        <React.Fragment>
            <h1>About</h1>
            <p>This is to do app created by kishan.</p>
        </React.Fragment>
    )
}
export default About;